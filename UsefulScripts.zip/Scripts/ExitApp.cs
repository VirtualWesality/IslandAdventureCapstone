﻿using UnityEngine;
using System.Collections;

public class ExitApp : MonoBehaviour {




	public void ExitApplication () {
		
			Application.Quit ();

	}
}
