﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class LoadScene : MonoBehaviour {

	public void LoadSceneNum (int num)
	{
		if (num < 0 || num >= SceneManager.sceneCountInBuildSettings) {
			Debug.LogWarning ("Can't load scene " + num + ", SceneManager only has "
			+ SceneManager.sceneCountInBuildSettings + " scenes in build settings!");
			return;
		}
		LoadingScreenManager.LoadScene (num);
	}
}
